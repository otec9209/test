package c

// This package is dot-imported by package b.

const C = 1
